
let particles=[];
let step=40;

function setup() {
  createCanvas(windowWidth, windowHeight);
  for (let x=step;x<windowWidth-step;x+=step){
    for (let y=step;y<windowHeight-step;y+=step){
      particles.push(new particle(x,y));
    }
  }
  background(200)
}


let mX=0;
let mY=0;

function draw() {
  mX=mouseX;
  mY=mouseY;
  for (c=particles.length-1;c>0;c--){
    particles[c].update();
    particles[c].show();
  }
  background(220,220,220,20);

}

function particle(x,y){
  this.x0=x;
  this.y0=y;
  this.pos=createVector(x,y);
  this.oldMove=createVector(0,0);
  this.rand=random(0.95,1.);

  this.update=function (){
    this.move=createVector(this.x0-this.pos.x,this.y0-this.pos.y).div(10).add(this.oldMove);
    this.oldMove=this.move.div(1.02);
    this.move.add(createVector(random()-0.5,random()-0.5).div(6));
    this.move.add(createVector(mX-this.pos.x,mY-this.pos.y).normalize().mult(6).div(sqrt(abs(mX-particles[c].pos.x)+abs(mY-particles[c].pos.y))));
    this.pos.add(this.move);
  }

  this.show=function(){

    strokeWeight(random(9.6,10.));
    point(this.pos.x,this.pos.y);
  }

}

function mousePressed(){
  for (c=particles.length-1;c>0;c--){
    particles[c].oldMove.add(createVector(mX-particles[c].pos.x,mY-particles[c].pos.y).normalize().mult(-20).div(sqrt(abs(mX-particles[c].pos.x)+abs(mY-particles[c].pos.y))/2.));
  }
}



